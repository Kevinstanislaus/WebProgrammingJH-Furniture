

<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="welcome">
        <h2><?php echo e(Auth::user()->fullname); ?>'s Profile</h2>
    </div>         

    <table class="profile">
        <tr>
            <td>Full Name</td>
            <td><?php echo e(Auth::user()->fullname); ?></td>
        </tr>

        <tr>
            <td>Email</td>
            <td><?php echo e(Auth::user()->email); ?></td>
        </tr>

        <tr>
            <td>Address</td>
            <td class="user_address" rowspan="2"><?php echo e(Auth::user()->address); ?></td>
        </tr>
        <tr></tr>

        <tr>
            <td>Gender</td>
            <td><?php echo e(Auth::user()->gender); ?></td>
        </tr>

        <tr>
            <td>Role</td>
            <td><?php echo e(Auth::user()->role); ?></td>
        </tr>

        <tr>
            
        </tr>
    </table>
   
    <div class="btn_group">
        <form action="/logout" method="POST" class="logout">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary loginbtn" type="submit" value="Logout"><a href="<?php echo e(route('logout')); ?>">Logout</a></button>
        </form>
        <button class="btn btn-primary loginbtn">View Transaction History</button>
        <button class="btn btn-primary loginbtn"><a href="<?php echo e(route('userUpdateProfile')); ?>">Update Profile</a></button>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\BE01-WebprogLab\JH Furniture\resources\views/user_profile.blade.php ENDPATH**/ ?>