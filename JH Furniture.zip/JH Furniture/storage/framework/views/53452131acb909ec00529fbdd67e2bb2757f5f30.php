

<?php $__env->startSection('title','Add Furniture'); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome">
    <h2>Add Furniture</h2>
</div>
    
<section>
    <form class="col-sm-3" action="/add-furniture" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label">Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="name" id="name" 
            required placeholder="Enter furniture's name">
          </div>
        </div>
        
        <div class="form-group row">
          <label for="price" class="col-sm-2 col-form-label">Price</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="price" id="price" required
            required placeholder="Enter furniture's price">
          </div>
        </div>

        <div class="form-group row">
            <label for="Type" class="col-sm-2 col-form-label">Type</label>
            <div class="form-group col-sm-10">
                <select id="inputState" class="form-control" name="type">
                  <option disabled selected>Choose furniture's type</option>
                  <option value="Living Room">Living Room</option>
                  <option value="Kitchen">Kitchen</option>
                  <option value="Decoration">Decoration</option>
                  <option value="Lamp and Electronic">Lamp and Electronic</option>
                  <option value="Storage">Storage</option>
                  <option value="Workstation">Workstation</option>
                </select>
              </div>
          </div>

          <div class="form-group row">
            <label for="Color" class="col-sm-2 col-form-label">Color</label>
            <div class="form-group col-sm-10">
                <select id="inputState" class="form-control" name="color"> 
                  <option disabled selected>Choose furniture's color</option>
                  <option value="Red">Red</option>
                  <option value="Green">Green</option>
                  <option value="Blue">Blue</option>
                  <option value="Yellow">Yellow</option>
                  <option value="Black">Black</option>
                  <option value="White">White</option>
                </select>
              </div>
          </div>

          <div class="form-group row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        File Upload
                    </div>
                    
                            <div class="form-group">
                                <label for="file">Choose File</label>
                                <input type="file" class="form-control" name="file" id="file">
                            </div>
                            
                        
                </div>
            </div>
        </div>

       
        <div class="form-group row">
          <div class="col-sm-10 offset-sm-3">
            <button type="submit" class="btn-updatebtn">Add Furniture</button>
          </div>
        </div>
      </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\new\JH Furniture\resources\views/add_furniture.blade.php ENDPATH**/ ?>