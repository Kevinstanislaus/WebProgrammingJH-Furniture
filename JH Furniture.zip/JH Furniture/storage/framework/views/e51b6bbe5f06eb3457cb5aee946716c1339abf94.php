

<?php $__env->startSection('title','Cart'); ?>

<?php $__env->startSection('content'); ?>
<div class="welcome">
    <h2>Cart</h2>
</div>   

<section class="isi-cart col-md-8 mx-auto">
    <table class="table table-borderless">
        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr >
                
                <td>  <img src="<?php echo e(Storage::url($cart->image)); ?>" alt="Gambar" style="max-width: 20vw; max-height: 10vh"></td>
                <td><?php echo e($cart->name); ?></td>
                <td>Rp. <?php echo e($cart->price); ?></td>
                <td><?php echo e($cart->quantity); ?> item(s)</td>
                <td>Rp. <?php echo e($cart->quantity * $cart->furniture->price); ?></td>
                <input type="hidden" name="grandtotal" value="<?php echo e($grandtotal += $cart->quantity * $cart->furniture->price); ?>">
                <td > 
                    
                    
                        <a class="btn btn-primary" href="/minus/<?php echo e($cart->id); ?>" role="button">-</a>
                        <a class="btn btn-primary" href="/plus/<?php echo e($cart->id); ?>" role="button">+</a>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <p class="total">Total : Rp <?php echo e($grandtotal); ?></p>
    
    <div class="cart">
        <a href="<?php echo e(route('checkout')); ?>"><button type="button" class="btn btn-primary btn-lg button-checkout">Proceed To Checkout</button></a>
       
    </div>
   
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\baur 10 jan\JH Furniture\resources\views/cart.blade.php ENDPATH**/ ?>