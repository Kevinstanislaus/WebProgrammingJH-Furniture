

<?php $__env->startSection('title','View Furniture'); ?>

<?php $__env->startSection('content'); ?>


<?php if(!Auth::check()): ?>
<div class="welcome">
    <h2>Nama Item</h2>
</div>
<section>
<div class="isi-tengah-update">
    <div class="gambar-kiri"><img src="" alt="">
        </div>
    <div class="bagian-kanan">
        <h5>Name:   </h5>
        <h5>Price:   </h5>
        <h5>Type:   </h5>
        <h5>Color:   </h5>
    </div>
    
</div>

<div class="isi-bawah-update">
    <div>
        <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
      </div>
    
      <div>
        <button type="button" class="btn btn-primary btn-lg ml-4 cart-btn">Add To Cart</button>
      </div>
</div>


</section>

<?php elseif(Auth::user()->role === 'Admin'): ?>    
<?php if(auth()->guard()->check()): ?>
<div class="welcome">
    <h2>Nama Item</h2>
</div>
<section>
<div class="isi-tengah-update">
    <div class="gambar-kiri"><img src="" alt="">
        </div>
    <div class="bagian-kanan">
        <h5>Name:   </h5>
        <h5>Price:   </h5>
        <h5>Type:   </h5>
        <h5>Color:   </h5>
    </div>
    
</div>

<div class="isi-bawah-update">
    <div>
        <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
      </div>
    
      <div>
        <button type="button" class="btn btn-primary btn-lg update-btn">Update</button>
      </div>
       
      <div>
        <button type="button" class="btn btn-primary btn-lg ml-4 delete-btn">Delete</button>
      </div>
</div>


</section>
<?php endif; ?>

<?php else: ?>    
<?php if(auth()->guard()->check()): ?>
<div class="welcome">
    <h2>Nama Item</h2>
</div>
<section>
<div class="isi-tengah-update">
    <div class="gambar-kiri"><img src="" alt="">
        </div>
    <div class="bagian-kanan">
        <h5>Name:   </h5>
        <h5>Price:   </h5>
        <h5>Type:   </h5>
        <h5>Color:   </h5>
    </div>
    
</div>

<div class="isi-bawah-update">
    <div>
        <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
      </div>
    
      <div>
        <button type="button" class="btn btn-primary btn-lg ml-4 cart-btn">Add To Cart</button>
      </div>
</div>


</section>
<?php endif; ?>
<?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\BE01-WebprogLab\JH Furniture\resources\views/view_furniture_detail.blade.php ENDPATH**/ ?>