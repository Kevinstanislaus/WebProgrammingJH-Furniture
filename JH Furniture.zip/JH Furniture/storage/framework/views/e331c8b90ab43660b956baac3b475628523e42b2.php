

<?php $__env->startSection('title','View'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!Auth::check()): ?>
            <div class="welcome">
                <h2>View Furniture</h2>
            </div>
            <form class="form-inline my-2 my-0 search-bar">
                <input class="form-control mr-sm-2 w-25" type="search" placeholder="Search by furniture's name" aria-label="Search">
                <button class="btn btn-outline-success my-2 my-sm-2 button-search" type="submit">Search</button>
              </form>
            <section>
                <div class="card-deck mx-5">

                    <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <a href="detail-furniture/<?php echo e($furniture->id); ?>"> 
                        <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                            </a>
                        <div class="card-body">
                            <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                            <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                            
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btnitem-1" >Add to Cart</button>
                        </div>
                        
                        </div>
            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </section>

        <?php elseif(Auth::user()->role === 'Admin'): ?>    
            <?php if(auth()->guard()->check()): ?>
                <div class="welcome">
                    <h2>View Furniture</h2>
                </div>
                <form class="form-inline my-2 my-0 search-bar">
                    <input class="form-control mr-sm-2 w-25" type="search" placeholder="Search by furniture's name" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-2 button-search" type="submit">Search</button>
                  </form>
                <section>
                    <div class="card-deck mx-5">
            
                        <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <a href="detail-furniture/<?php echo e($furniture->id); ?>"> 
                            <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                                </a>
                            <div class="card-body">
                                <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                                <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                                
                            </div>
                            <div class="card-footer">
                                <a href="update-furniture/<?php echo e($furniture->id); ?>"><button type="button" class="btn btn-success btn-update">Update</button></a>
                                <a href="/delete-furniture/<?php echo e($furniture->id); ?>"><button type="button" class="btn btn-danger btn-delete">Delete</button></a>
                            </div>
                            
                            </div>
                     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

        <?php else: ?>    
            <?php if(auth()->guard()->check()): ?>
                <div class="welcome">
                    <h2>Welcome, <?php echo e(Auth::user()->fullname); ?></h2>
                    <h2>to JH Furniture</h2>
                </div>

                <form class="form-inline my-2 my-0 search-bar">
                    <input class="form-control mr-sm-2 w-25" type="search" placeholder="Search by furniture's name" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-2 button-search" type="submit">Search</button>
                  </form>

                <section>
                    <div class="card-deck mx-5">
            
                        <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <a href="detail-furniture/<?php echo e($furniture->id); ?>"> 
                        <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                            </a>
                        <div class="card-body">
                            <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                            <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                            
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btnitem-1" >Add to Cart</button>
                        </div>
                        
                        </div>
                
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                    </div>
                </section>
            <?php endif; ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\JH Furniture\resources\views/view_furniture.blade.php ENDPATH**/ ?>