

<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->role === 'Admin'): ?>
        <div class="welcome">
            <h2>Admin's Profile</h2>
        </div>         

        <table class="profile">
            <tr>
                <td>Full Name</td>
                <td><?php echo e(Auth::user()->fullname); ?></td>
            </tr>

            <tr>
                <td>Email</td>
                <td><?php echo e(Auth::user()->email); ?></td>
            </tr>

            <tr>
                <td>Role</td>
                <td><?php echo e(Auth::user()->role); ?></td>
            </tr>
        </table>

        <div class="btn_group">
            <form action="/logout" method="POST" class="logout">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('logout')); ?>"><button class="btn btn-primary profile-btn" type="submit" value="Logout">Logout</button></a>
            </form>
            <a href="<?php echo e(route('viewTransaction')); ?>"><button class="btn btn-primary profile-btn">View Transaction History</button></a>
            <a href="<?php echo e(route('updateProfile')); ?>"><button class="btn btn-primary profile-btn">Update Profile</button></a>
        </div>
    <?php elseif(Auth::user()->role === 'Member'): ?>
        <div class="welcome">
            <h2><?php echo e(Auth::user()->fullname); ?>'s Profile</h2>
        </div>         

        <table class="profile">
            <tr>
                <td>Full Name</td>
                <td><?php echo e(Auth::user()->fullname); ?></td>
            </tr>

            <tr>
                <td>Email</td>
                <td><?php echo e(Auth::user()->email); ?></td>
            </tr>

            <tr>
                <td>Address</td>
                <td class="user_address" rowspan="2"><?php echo e(Auth::user()->address); ?></td>
            </tr>
            <tr></tr>

            <tr>
                <td>Gender</td>
                <td><?php echo e(Auth::user()->gender); ?></td>
            </tr>

            <tr>
                <td>Role</td>
                <td><?php echo e(Auth::user()->role); ?></td>
            </tr>

            <tr>
                
            </tr>
        </table>

        <div class="btn_group">
            <form action="/logout" method="POST" class="logout">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('logout')); ?>"><button class="btn btn-primary profile-btn" type="submit" value="Logout">Logout</button></a>
            </form>
            <a href="<?php echo e(route('viewTransaction')); ?>"><button class="btn btn-primary profile-btn">View Transaction History</button></a>
            <a href="<?php echo e(route('updateProfile')); ?>"><button class="btn btn-primary profile-btn">Update Profile</button></a>
        </div>
    <?php endif; ?> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\JH Furniture\resources\views/profile.blade.php ENDPATH**/ ?>