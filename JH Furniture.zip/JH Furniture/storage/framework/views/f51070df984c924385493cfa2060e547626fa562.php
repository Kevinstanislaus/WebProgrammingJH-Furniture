

<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="welcome">
        <h2>Admin's Profile</h2>
    </div>         

    <table class="profile">
        <tr>
            <td>Full Name</td>
            <td><?php echo e(Auth::user()->fullname); ?></td>
        </tr>

        <tr>
            <td>Email</td>
            <td><?php echo e(Auth::user()->email); ?></td>
        </tr>

        <tr>
            <td>Role</td>
            <td><?php echo e(Auth::user()->role); ?></td>
        </tr>
    </table>

    <div class="btn_group">
        <form action="/logout" method="POST" class="logout">
            <?php echo csrf_field(); ?>
            <button class="btn btn-primary loginbtn" type="submit" value="Logout"><a href="<?php echo e(route('logout')); ?>">Logout</a></button>
        </form>
        <button class="btn btn-primary loginbtn">View All User's Transaction</button>
        <button class="btn btn-primary loginbtn"><a href="<?php echo e(route('adminUpdateProfile')); ?>">Update Profile</a></button>
    </div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Responsi\JH Furniture\resources\views/admin_profile.blade.php ENDPATH**/ ?>