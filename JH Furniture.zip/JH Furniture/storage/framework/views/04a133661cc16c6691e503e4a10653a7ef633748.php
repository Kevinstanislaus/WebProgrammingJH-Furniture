

<?php $__env->startSection('title','Home'); ?>

<?php $__env->startSection('content'); ?>
<?php if(!Auth::check()): ?>
<div class="welcome">
    <h2>Welcome to JH Furniture</h2>
</div>

<section>
    <div class="card-deck mx-5">

        <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="card home-img">
                <a href="detail-furniture/<?php echo e($furniture->id); ?>">
                    <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                </a>
                <div class="card-body">
                    <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                    <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                    
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('login')); ?>"> <button type="submit" class="btnitem-1">Add to Cart</button></a>
                </div>
    
            </div>
      
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>

<?php elseif(Auth::user()->role === 'Admin'): ?>
<?php if(auth()->guard()->check()): ?>
<div class="welcome">
    <h2>Welcome, Admin</h2>
    <h2>to JH Furniture</h2>
</div>

<section>
    <div class="card-deck mx-5">

        <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="card home-img">
                <a href="<?php echo e(route('detailFurniture', $furniture)); ?>">
                    <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                </a>
                <div class="card-body">
                    <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                    <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                    
                </div>
                <div class="card-footer">
                    <a href="/update-furniture/<?php echo e($furniture->id); ?>"><button type="button"
                            class="btn btn-success btn-update">Update</button></a>
                    
                    <div class="col-3">
                        <form action="<?php echo e(url('delete-furniture/'.$furniture->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <button
                                type="submit" class="btn btn-danger btn-delete" style="border: none">Delete </button> </form>
                    </div>
                </div>
    
            </div>
       
        

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
<?php endif; ?>

<?php else: ?>
<?php if(auth()->guard()->check()): ?>
<div class="welcome">
    <h2>Welcome, <?php echo e(Auth::user()->fullname); ?></h2>
    <h2>to JH Furniture</h2>
</div>

<section>
    <div class="card-deck mx-5">

        <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      
            <div class="card home-img ">
                <a href="detail-furniture/<?php echo e($furniture->id); ?>">
                    <img src="<?php echo e(Storage::url($furniture->image)); ?>" class="card-img-top" alt="...">
                </a>
                <div class="card-body">
                    <h5 class="card-title information"><?php echo e($furniture->name); ?></h5>
                    <p class="card-text information">Rp. <?php echo e($furniture->price); ?></p>
                    
                </div>
                <div class="card-footer">
                    
                    <a class="btn btn-primary" href="/cart/<?php echo e($furniture->id); ?>" role="button">Add to Cart</a>
                    
                </div>
                
            </div>
       
       
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    <?php if(session()->has('success')): ?>
       <p style="text-align: center; font-size:2vw"> <?php echo e(session()->get('success')); ?></p>
    <?php endif; ?>
</section>
<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\baur 10 jan\JH Furniture\resources\views/home.blade.php ENDPATH**/ ?>