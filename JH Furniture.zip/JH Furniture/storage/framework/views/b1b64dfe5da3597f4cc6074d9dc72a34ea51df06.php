

<?php $__env->startSection('title','Transaction History'); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome">
    <h2>Transaction History</h2>
</div>   

<section>
    <div class="bungkus-transaksi mx-5" >

        <table class="data_transaksi">
            <tr>
                <td>Transaction ID : </td>
            
            </tr>
    
            <tr>
                <td>Transaction Date :</td>
       
            </tr>
    
            <tr>
                <td>Method :</td>
                
            </tr>
            <tr></tr>
    
            <tr>
                <td>Card Number : </td>
                <td>bdbdbdbd</td>
            </tr>
    
            <tr>
                <td>User's Name : </td>
                <td>HAHHAHA</td>
            </tr>
    
            <tr>
                
            </tr>
        </table>
        <table class="table table-bordered isi-transaksi">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">First</th>
                <th scope="col">Last</th>
                <th scope="col">Handle</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">1</th>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <th scope="row">2</th>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <th scope="row">3</th>
                <td colspan="2">Larry the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
          </table>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\new\JH Furniture\resources\views/transaction_history.blade.php ENDPATH**/ ?>