

<?php $__env->startSection('title','Login'); ?>

<?php $__env->startSection('content'); ?>
    <h3 id="login_title">Login</h3>

    

    <form class="col-sm-3" action="/login" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-group row">
        <label for="email" class="col-sm-2 col-form-label">Email</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" name="email" id="email" required>
        </div>
      </div>
      <div class="form-group row">
        <label for="password" class="col-sm-2 col-form-label">Password</label>
        <div class="col-sm-10">
          <input type="password" class="form-control" name="password" id="password" required>
        </div>
      </div>
      <div class="form-group row">
        <div class="col-sm-10 offset-sm-4">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="remember" name="remember">
            <label class="form-check-label" for="remember">
              Remember Me
            </label>
          </div>
        </div>
      </div>
      <div class="form-group row">
        <div class="col-sm-10 offset-sm-3">
          <button type="submit" class="btn btn-primary loginbtn" value="Login">Login</button>
        </div>
      </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\JH Furniture\resources\views/login.blade.php ENDPATH**/ ?>