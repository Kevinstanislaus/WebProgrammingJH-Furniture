

<?php $__env->startSection('title','Furniture Detail'); ?>

<?php $__env->startSection('content'); ?>


<?php if(!Auth::check()): ?>

<?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="welcome">
        <h2><?php echo e($furniture->name); ?></h2>
    </div>
    <section>
        <div class="isi-tengah-update">
            <div class="gambar-kiri"><img src="" alt="">
                </div>
            <div class="bagian-kanan">
                <table class="table table-borderless detail">
                    <tr>
                        <td>Name :</td>
                        <td class="detail-info"><?php echo e($furniture->name); ?></td>
                    </tr>

                    <tr>
                        <td>Price :</td>
                        <td class="detail-info">Rp. <?php echo e($furniture->price); ?></td>
                    </tr>

                    <tr>
                        <td>Type :</td>
                        <td class="detail-info"><?php echo e($furniture->type); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Color :</td>
                        <td class="detail-info"><?php echo e($furniture->color); ?></td>
                    </tr>
                </table>
            </div>
            
        </div>

        <div class="isi-bawah-update">
            <div>
                <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
            </div>
            
            <div>
                <a href="<?php echo e(route('login')); ?>"><button type="button" class="btn btn-primary btn-lg ml-4 cart-btn">Add To Cart</button></a>
            </div>
        </div>
    
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php elseif(Auth::user()->role === 'Admin'): ?>    
    <?php if(auth()->guard()->check()): ?>
    <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
        <div class="welcome">
            <h2><?php echo e($furniture->name); ?></h2>
        </div>
        <section>
            <div class="isi-tengah-update">
                <div class="gambar-kiri"><img src="" alt="">
                    </div>
                <div class="bagian-kanan">
                    <table class="table table-borderless detail">
                        <tr>
                            <td>Name :</td>
                            <td class="detail-info"><?php echo e($furniture->name); ?></td>
                        </tr>

                        <tr>
                            <td>Price :</td>
                            <td class="detail-info">Rp. <?php echo e($furniture->price); ?></td>
                        </tr>

                        <tr>
                            <td>Type :</td>
                            <td class="detail-info"><?php echo e($furniture->type); ?></td>
                        </tr>
                        
                        <tr>
                            <td>Color :</td>
                            <td class="detail-info"><?php echo e($furniture->color); ?></td>
                        </tr>
                    </table>
                </div>
                
            </div>

            <div class="isi-bawah-update">
                <div>
                    <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
                </div>
                
                <div>
                    <a href="/update-furniture/<?php echo e($furniture->id); ?>"><button type="button" class="btn btn-primary btn-lg update-btn">Update</button></a>
                </div>
                
                <div>
                    <a href="/delete-furniture/<?php echo e($furniture->id); ?>"><button type="button" class="btn btn-primary btn-lg ml-4 delete-btn">Delete</button></a>
                </div>
            </div>

        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

<?php else: ?>    
    <?php if(auth()->guard()->check()): ?>
    <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="welcome">
            <h2><?php echo e($furniture->name); ?></h2>
        </div>
        <section>
        <div class="isi-tengah-update">
            <div class="gambar-kiri"><img src="" alt="">
                </div>
            <div class="bagian-kanan">
                <table class="table table-borderless detail">
                    <tr>
                        <td>Name :</td>
                        <td class="detail-info"><?php echo e($furniture->name); ?></td>
                    </tr>

                    <tr>
                        <td>Price :</td>
                        <td class="detail-info">Rp. <?php echo e($furniture->price); ?></td>
                    </tr>

                    <tr>
                        <td>Type :</td>
                        <td class="detail-info"><?php echo e($furniture->type); ?></td>
                    </tr>
                    
                    <tr>
                        <td>Color :</td>
                        <td class="detail-info"><?php echo e($furniture->color); ?></td>
                    </tr>
                </table>
            </div>
            
        </div>

        <div class="isi-bawah-update">
            <div>
                <button type="button" class="btn btn-primary btn-lg mr-4 previous-btn">Previous</button>
            </div>
            
            <div>
                <button type="button" class="btn btn-primary btn-lg ml-4 cart-btn">Add To Cart</button>
            </div>
        </div>

        </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\new\JH Furniture\resources\views/view_furniture_detail.blade.php ENDPATH**/ ?>