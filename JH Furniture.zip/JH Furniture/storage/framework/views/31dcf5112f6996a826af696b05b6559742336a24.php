

<?php $__env->startSection('title','Cart Checkout'); ?>

<?php $__env->startSection('content'); ?>
<div class="welcome">
    <h2>Cart</h2>
</div>   

<section class="isi-cart col-md-8 mx-auto">
    <table class="table table-borderless">
        <tr >
            <td>  <img src="" alt="Gambar"></td>
            <td>Nama Product</td>
            <td >Harga Barang</td>
            <td>Jumlah Item</td>
            <td >Harga Total</td>
            <td > <button type="button" class="btn btn-secondary button-min">-</button>
                <button type="button" class="btn btn-secondary button-plus">+</button></td>
        </tr>
    </table>

    <p class="total">Total : Rp 7.283.930,-</p>
    <div class="form-group row">
        <label for="payment" class="col-sm-2 col-form-label">Payment Method</label>
        <div class="form-check form-check-inline col-sm-3 offset-sm-2">
            <input class="form-check-input" type="radio" name="payment" id="credit" value="Credit" required>
            <label class="form-check-label" for="credit"><b>Credit</b></label>
        </div>
        <div class="form-check form-check-inline col-sm-3">
            <input class="form-check-input" type="radio" name="payment" id="debit" value="Debit" required>
            <label class="form-check-label" for="debit"><b>Debit</b></label>
        </div>

        
    </div>
    <div class="form-group row">
        <label for="email" class="col-sm-2 col-form-label">Card Number</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="card" id="card" required>
        </div>
      </div>
 
    <div class="cart">
        <button type="button" class="btn btn-primary btn-lg button-checkout">Proceed To Checkout</button>
    </div>
   
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\BE01-WebprogLab\JH Furniture\resources\views/cart_checkout.blade.php ENDPATH**/ ?>