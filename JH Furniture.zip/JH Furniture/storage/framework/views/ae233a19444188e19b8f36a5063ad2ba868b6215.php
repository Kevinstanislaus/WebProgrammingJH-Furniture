

<?php $__env->startSection('title','Update Furniture'); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome">
    <h2>Update Furniture</h2>
</div>
    
<section>
    <?php $__currentLoopData = $furniture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $furniture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <form class="col-sm-3" action="/update-furniture/<?php echo e($furniture->id); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group row">
            <label for="name" class="col-sm-2 col-form-label">Name</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" value="<?php echo e($furniture->name); ?>" required>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          
          <div class="form-group row">
            <label for="price" class="col-sm-2 col-form-label">Price</label>
            <div class="col-sm-10">
              <input type="text" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" id="price" value="<?php echo e($furniture->price); ?>" required>
              <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback">
                <?php echo e($message); ?>

              </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>

          <div class="form-group row">
              <label for="Type" class="col-sm-2 col-form-label">Type</label>
              <div class="form-group col-sm-10">
                  <select id="inputState" class="form-control  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="type" value="<?php echo e($furniture->type); ?>" required>
                    <option disabled selected>Choose furniture's type</option>
                    <option <?php echo e(($furniture->type) == 'Living Room' ? 'selected' : ''); ?>  value="Living Room">Living Room</option>
                    <option <?php echo e(($furniture->type) == 'Kitchen' ? 'selected' : ''); ?>  value="Kitchen">Kitchen</option>
                    <option <?php echo e(($furniture->type) == 'Decoration' ? 'selected' : ''); ?>  value="Decoration">Decoration</option>
                    <option <?php echo e(($furniture->type) == 'Lamp and Electronic' ? 'selected' : ''); ?>  value="Lamp and Electronic">Lamp and Electronic</option>
                    <option <?php echo e(($furniture->type) == 'Storage' ? 'selected' : ''); ?>  value="Storage">Storage</option>
                    <option <?php echo e(($furniture->type) == 'Workstation' ? 'selected' : ''); ?>  Workstation">Workstation</option>
                  </select>
                  <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                    <?php echo e($message); ?>

                  </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
              <label for="Color" class="col-sm-2 col-form-label">Color</label>
              <div class="form-group col-sm-10">
                  <select id="inputState" class="form-control <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="color" value="<?php echo e($furniture->color); ?>" required>
                    <option disabled selected>Choose furniture's color</option>
                    <option <?php echo e(($furniture->color) == 'Red' ? 'selected' : ''); ?>  value="Red">Red</option>
                    <option <?php echo e(($furniture->color) == 'Green' ? 'selected' : ''); ?>  value="Green">Green</option>
                    <option <?php echo e(($furniture->color) == 'Blue' ? 'selected' : ''); ?>  value="Blue">Blue</option>
                    <option <?php echo e(($furniture->color) == 'Yellow' ? 'selected' : ''); ?>  value="Yellow">Yellow</option>
                    <option <?php echo e(($furniture->color) == 'Black' ? 'selected' : ''); ?>  value="Black">Black</option>
                    <option <?php echo e(($furniture->color) == 'White' ? 'selected' : ''); ?>  value="White">White</option>
                  </select>
                  <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback">
                    <?php echo e($message); ?>

                  </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-group row">
              <label for="Image" class="col-sm-2 col-form-label">Image</label>
              <div class="col-sm-10">
                <input type="file" class="form-control py-1 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($furniture->image); ?>" name="image" id="image" >
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger">
                <?php echo e($message); ?>

              </div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>

        
          <div class="form-group row">
            <div class="col-sm-10 offset-sm-3">
              <button type="submit" class="btn-updatebtn">Update Furniture</button>
            </div>
          </div>
        </form>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\baur 10 jan\JH Furniture\resources\views/update_furniture.blade.php ENDPATH**/ ?>