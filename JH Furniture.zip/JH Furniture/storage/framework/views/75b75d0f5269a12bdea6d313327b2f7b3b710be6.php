

<?php $__env->startSection('title','Transaction History'); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome">
    <h2>Transaction History</h2>
</div>   

<?php if(Auth::user()->role === 'Admin'): ?>
  <section>
    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
      <div class="bungkus-transaksi mx-5 tabel-history" >

          <table class="data_transaksi">
              <tr>
                  <td>Transaction ID : <?php echo e($data->id); ?> </td>
              
              </tr>
      
              <tr>
                  <td>Transaction Date : <?php echo e($data->created_at); ?></td>
        
              </tr>
      
              <tr>
                  <td>Method : <?php echo e($data->method); ?></td>
                  
              </tr>
              <tr></tr>
      
              <tr>
                  <td>Card Number : <?php echo e($data->cardnumber); ?></td>
              </tr>
      
              <tr>
                  <td>User's Name : <?php echo e($data->account->fullname); ?></td>
              </tr>
     
              <tr>

              </tr>
          </table>
          <table class="table table-bordered isi-transaksi">
              <thead>
                <tr>
                  <th scope="col">Furniture's Name</th>
                  <th scope="col">Furniture's Price</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Total Price For Each Furniture</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($d->id == $data->id): ?>
                      <tr>
                        <td><?php echo e($d->name); ?></td>
                        <td>Rp. <?php echo e($d->price); ?></td>
                        <td><?php echo e($d->quantity); ?></td>
                        <td>Rp. <?php echo e($d->quantity * $d->price); ?></td>
                        <input type="hidden" name="grandtotal" value="<?php echo e($grandtotal += $d->quantity *$d->price); ?>">
                      </tr>
                    
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td colspan="3">Total Price</td>
                  <td>Rp. <?php echo e($grandtotal); ?></td>
                </tr>
              </tbody>
            </table>

      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </section>

<?php else: ?>
    <section>
      <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
        <div class="bungkus-transaksi mx-5 tabel-history" >

            <table class="data_transaksi">
                <tr>
                    <td>Transaction ID : <?php echo e($data->id); ?> </td>
                
                </tr>
        
                <tr>
                    <td>Transaction Date : <?php echo e($data->created_at); ?></td>
          
                </tr>
        
                <tr>
                    <td>Method : <?php echo e($data->method); ?></td>
                    
                </tr>
                <tr></tr>
        
                <tr>
                    <td>Card Number : <?php echo e($data->cardnumber); ?></td>
                </tr>
        
                <tr>

                </tr>
            </table>
            <table class="table table-bordered isi-transaksi">
                <thead>
                  <tr>
                    <th scope="col">Furniture's Name</th>
                    <th scope="col">Furniture's Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total Price For Each Furniture</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($d->id == $data->id): ?>
                      <tr>
                        <td><?php echo e($d->name); ?></td>
                        <td>Rp. <?php echo e($d->price); ?></td>
                        <td><?php echo e($d->quantity); ?></td>
                        <td>Rp. <?php echo e($d->quantity * $d->price); ?></td>
                        <input type="hidden" name="grandtotal" value="<?php echo e($grandtotal += $d->quantity *$d->price); ?>">
                      </tr>
                      
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td colspan="3">Total Price</td>
                    <td>Rp. <?php echo e($grandtotal); ?></td>
                  </tr>
                </tbody>
              </table>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
  
<?php endif; ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Steven\Binus\Semester 5\Web Programming\Lab\Project\baur 10 jan\JH Furniture\resources\views/transaction_history.blade.php ENDPATH**/ ?>