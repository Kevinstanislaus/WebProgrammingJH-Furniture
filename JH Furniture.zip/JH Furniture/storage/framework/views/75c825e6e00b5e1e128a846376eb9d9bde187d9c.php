

<?php $__env->startSection('title','Update Furniture'); ?>

<?php $__env->startSection('content'); ?>

<div class="welcome">
    <h2>Update Furniture</h2>
</div>
    
<section>
    <form class="col-sm-3" action="/login" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group row">
          <label for="name" class="col-sm-2 col-form-label">Name</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="name" id="name" 
            required placeholder="Enter furniture's name">
          </div>
        </div>
        
        <div class="form-group row">
          <label for="price" class="col-sm-2 col-form-label">Price</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" name="price" id="price" required
            required placeholder="Enter furniture's price">
          </div>
        </div>

        <div class="form-group row">
            <label for="Type" class="col-sm-2 col-form-label">Type</label>
            <div class="form-group col-sm-10">
                <select id="inputState" class="form-control">
                  <option selected>Choose furniture's type</option>
                  <option>...</option>
                </select>
              </div>
          </div>

          <div class="form-group row">
            <label for="Color" class="col-sm-2 col-form-label">Color</label>
            <div class="form-group col-sm-10">
                <select id="inputState" class="form-control">
                  <option selected>Choose furniture's color</option>
                  <option>...</option>
                </select>
              </div>
          </div>

          <div class="form-group row">
            <label for="Image" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10">
              <input type="file" class="form-control py-1" name="image" id="image" required>
            </div>
          </div>

       
        <div class="form-group row">
          <div class="col-sm-10 offset-sm-3">
            <button type="submit" class="btn-updatebtn">Update Furniture</button>
          </div>
        </div>
      </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\BE01-WebprogLab\JH Furniture\resources\views/update_furniture.blade.php ENDPATH**/ ?>