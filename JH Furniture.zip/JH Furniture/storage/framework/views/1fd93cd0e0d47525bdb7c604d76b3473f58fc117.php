

<?php $__env->startSection('title','Cart'); ?>

<?php $__env->startSection('content'); ?>
<div class="welcome">
    <h2>Cart</h2>
</div>   

<section class="isi-cart col-md-8 mx-auto">
    <table class="table table-borderless">
        <tr >
            <td>  <img src="" alt="Gambar"></td>
            <td>Nama Product</td>
            <td >Harga Barang</td>
            <td>Jumlah Item</td>
            <td >Harga Total</td>
            <td > <button type="button" class="btn btn-secondary button-min">-</button>
                <button type="button" class="btn btn-secondary button-plus">+</button></td>
        </tr>
    </table>

    <p class="total">Total : Rp 7.283.930,-</p>
    <div class="cart">
        <a href="<?php echo e(route('checkout')); ?>"><button type="button" class="btn btn-primary btn-lg button-checkout">Proceed To Checkout</button></a>
       
    </div>
   
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\Semester 5\Web Programming\BE01-WebprogLab\JH Furniture\resources\views/cart.blade.php ENDPATH**/ ?>